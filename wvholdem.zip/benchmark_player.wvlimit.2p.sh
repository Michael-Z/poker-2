#!/bin/bash
./benchmark_player wvholdem.limit.2p.game $1 $2
